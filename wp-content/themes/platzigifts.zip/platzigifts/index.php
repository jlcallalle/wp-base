<?php get_header(); ?>

<div class="container">
     <p>contenido</p>
</div>

<?php get_footer(); ?>