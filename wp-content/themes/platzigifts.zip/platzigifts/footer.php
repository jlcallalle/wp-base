<footer>
    <div class="container">
        <p> footer 123 </p>
        <?php dynamic_sidebar('footer'); ?>
    </div>
</footer>


<?php wp_footer() ?>

</body>
</html>